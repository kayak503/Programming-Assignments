#include <iostream>
#include <string>

using namespace std;

int main()
{
    int value1 = 50;
    int value2 = 100;
    string msg = "Total:";

    
    cout << msg << to_string(value1+value2);

}